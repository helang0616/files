from cloudant import Cloudant
from flask import Flask, render_template, request, jsonify
import atexit
import os
import json
import requests,json,smtplib,time
from email.mime.text import MIMEText
from email.utils import formataddr
import datetime,random,sys,os,pymysql,traceback
app = Flask(__name__, static_url_path='')
server='47.101.139.4'  #IP地址
datauser='score' #数据库账号
datapwd='123456789'  #数据库密码
database='score'  #数据库名
table='user'  #表名
db_name = 'mydb'
client = None
db = None

if 'VCAP_SERVICES' in os.environ:
    vcap = json.loads(os.getenv('VCAP_SERVICES'))
    print('Found VCAP_SERVICES')
    if 'cloudantNoSQLDB' in vcap:
        creds = vcap['cloudantNoSQLDB'][0]['credentials']
        user = creds['username']
        password = creds['password']
        url = 'https://' + creds['host']
        client = Cloudant(user, password, url=url, connect=True)
        db = client.create_database(db_name, throw_on_exists=False)
elif "CLOUDANT_URL" in os.environ:
    client = Cloudant(os.environ['CLOUDANT_USERNAME'], os.environ['CLOUDANT_PASSWORD'], url=os.environ['CLOUDANT_URL'], connect=True)
    db = client.create_database(db_name, throw_on_exists=False)
elif os.path.isfile('vcap-local.json'):
    with open('vcap-local.json') as f:
        vcap = json.load(f)
        print('Found local VCAP_SERVICES')
        creds = vcap['services']['cloudantNoSQLDB'][0]['credentials']
        user = creds['username']
        password = creds['password']
        url = 'https://' + creds['host']
        client = Cloudant(user, password, url=url, connect=True)
        db = client.create_database(db_name, throw_on_exists=False)

# On IBM Cloud Cloud Foundry, get the port number from the environment variable PORT
# When running this app on the local machine, default the port to 8000
port = int(os.getenv('PORT', 8000))

@app.route('/getscore', methods=['GET', 'POST'])
def getscore():
    user =  request.args.get("name") or ""
    if(user!=""):
        Cookie = getCookie(user)
        if(Cookie!=None):
            count, info = getInfo(Cookie)
            return info
        else:
            return "该信息未添加"
    else:
        return "url有误"

@app.route('/')
def root():
    return '福建师范大学成绩查询，更多信息<a href ="http://47.101.139.4/score/" >点击了解</a>'


@atexit.register
def shutdown():
    if client:
        client.disconnect()


sender='749832133@qq.com'    # 发件人邮箱账号
password = 'zkwpjrzwrbyibbca'      #  授权码，进入qq邮箱--设置--账户--开启POP3/SMTP服务--生成授权码
reciver = '1481604320@qq.com'      # 收件人邮箱账号
def getInfo(Cookie):
    url = 'https://jwglxt.fjnu.edu.cn/cjcx/cjcx_cxDgXscj.html?doType=query&gnmkdm=N305005'
    headers = {
        'Host': 'jwglxt.fjnu.edu.cn',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
        'Accept-Encoding': 'gzip, deflate, br',
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Content-Length': '148',
        'Origin': 'https://jwglxt.fjnu.edu.cn',
        'Connection': 'keep-alive',
        'Referer': 'https://jwglxt.fjnu.edu.cn/cjcx/cjcx_cxDgXscj.html?gnmkdm=N305005&layout=default&su=116072017036',
        'Cookie': Cookie,
        'TE': 'Trailers'
    }
    data = {
        'xnm':"2019",
        'xqm':"12",
        '_search':"false",
        'nd':"1593162087469",
        'queryModel.showCount':"15",
        'queryModel.currentPage':"1",
        'queryModel.sortName':"",
        'queryModel.sortOrder':"asc",
        'time':"1"
    }
    resp = requests.post(url,headers=headers,data=data)
    data = json.loads(resp.text)
    count = data['totalCount']
    items = data['items']
    info = ""   #成绩详情
    for item in items:
        Course = item['kcmc']
        Score = item['cj']
        info+=Course+ " " +Score+"\n"
    return count,info

def sendEmail(sender,password,reciver,info):
    state = True
    try:
        msg = MIMEText(info, 'plain', 'utf-8')  # 填写邮件内容
        msg['From'] = formataddr(["", sender])  # 括号里的对应发件人邮箱昵称、发件人邮箱账号
        msg['To'] = formataddr(["", reciver])  # 括号里的对应收件人邮箱昵称、收件人邮箱账号
        msg['Subject'] = "成绩自动查询"  # 邮件的主题，也可以说是标题
        server = smtplib.SMTP_SSL("smtp.qq.com", 465)  # 发件人邮箱中的SMTP服务器，端口是25
        server.login(sender, password)  # 括号中对应的是发件人邮箱账号、邮箱密码
        server.sendmail(sender, [reciver, ], msg.as_string())  # 括号中对应的是发件人邮箱账号、收件人邮箱账号、发送邮件
        server.quit()  # 关闭连接
    except Exception:  # 如果 try 中的语句没有执行，则会执行下面的 ret=False
        state = False
    return state

def setCount(count):
    with open("count.txt" , "w+") as f:
        f.write(str(count))

def getCount():
    try:
        with open("count.txt", "r") as f:
                return int(f.read())
    except:
        return 0

def isSend(num):
    count = getCount()
    if(num > count):
        setCount(num)
        return True
    return False
def getCookie(user):
    try:
        db = pymysql.connect(server, datauser, datapwd, database)
        cur = db.cursor()
        cur.execute("SELECT * FROM " + table + " WHERE `user_name` = '"+user+"'")
        dataList = cur.fetchall()
        db.close()
        if(len(dataList)==0):
            return None
        else:
            return dataList[0][1]
    except Exception as e:
        print(traceback.format_exc())
    db.close()

def main():
    count, info = getInfo("Secure; JSESSIONID=9455BD64AC144CCFC2872C42ADC7BA91; Secure")
    state = isSend(count)
    if(state):
        state = sendEmail(sender, password, reciver, info)
        sendEmail(sender, password, "1439651427@qq.com", "成绩已出")
        sendEmail(sender, password, "1164221036@qq.com", "成绩已出")
        sendEmail(sender, password, "1843264686@qq.com", "成绩已出")
        if(state):
            print("发送成功")
        else:
            print("发送失败")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=port, debug=True)
    while(True):
        main()
        time.sleep(60)

